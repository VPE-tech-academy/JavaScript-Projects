window.alert("Welcome to Assignment 86")

function myFunction () {
    var Add = 2 + 2;
    document.getElementById("Math").innerHTML = " The answer of 2 + 2 is " + Add + ".";
}

function myFunction2 () {
    document.getElementById("mathRandom").innerHTML = "If you are holding ticket no. " + Math.floor(Math.random()*150) + ", you are the winner! Congratulations!";
}

function myFunction3 () {
    var X = 5;
    X++
    document.getElementById("Increment").innerHTML = X;
}

function myFunction4 () {
    var X = 12;
    X--
    document.getElementById("Decrement").innerHTML = X;
}

function myFunction5 () {
    var X, Y, Z;
    X = 90;
    Y = 95;
    Z = 89;
    Sum = X+Y+Z;
    Average =Sum / 3;
    document.getElementById("Average").innerHTML = Average;
}
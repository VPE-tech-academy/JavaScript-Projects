window.alert("Welcome to my Assignment page!")

var myDogBreed="My dog is a Boston Terrier."+" She is sweet and loving."
var myDogBreed=myDogBreed.fontcolor("brown")
document.write(myDogBreed);

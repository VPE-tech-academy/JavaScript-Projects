function my_Dictionary () {
    var Student1 = {
        Physics: 90,
        Algebra: 85,
        English: 92,
        PE: 88,
        PE: 90
    };
    delete Student1.PE;
    document.getElementById("Dictionary").innerHTML = Student1.PE;
}
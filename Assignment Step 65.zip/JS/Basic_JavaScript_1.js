window.alert("Welcome to my Assignment page!") //alert to welcome visitors to page

var myDogBreed="My dog is a Boston Terrier."+" She is sweet and loving." //creating strings
var myDogBreed=myDogBreed.fontcolor("brown") //changing font color
document.write(myDogBreed);

function function1 (){
    document.write (5==5);
}

function function2 (){
    document.write ("5"===5);
}

function function3 (){
    document.write (5<2);
}

function function4 (){
    document.write (5>2);
}

function function5 (){
    document.write (5>2 && 5<6);
}

function function6 (){
    document.write (5<2 || 5<6);
}

function function7 (){
    document.getElementById("Not").innerHTML = !(50>20);
}
function Vote() {
    var Age, Can_Vote;
    Age = document.getElementById("Age").value;
    Can_Vote = (Age > 17)? "You may proceed to the voting station to exercise your right to vote.":"You are still not qualified to vote.";
    document.getElementById("Vote1").innerHTML = Can_Vote + " Thank you for coming.";
}
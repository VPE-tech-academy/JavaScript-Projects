function count_Function() {
    document.getElementById("MultiplicationTable2").innerHTML=Count();
    function() {
        var Starting_point = 0;
        function Plus_two() {Starting_point += 2;}
        Plus_two();
        return Starting_point;
    }
}
function Dog(Breed, Age, Color) {
    this.Dog_Breed = Breed;
    this.Dog_Age = Age;
    this.Dog_Color = Color;
}
var Bona = new Dog ("Boston Terrier", 12, "Red");
    Snappie = new Dog ("Poodle", 12, "Black");
    Lucho = new Dog ("Labrador", 5, "Yellow");
function dogFunction() {
    document.getElementById("ThisNew").innerHTML = "Ellen's dog is named Bona. She is a " + Bona.Dog_Age + Bona.Dog_Color + Bona.Dog_Breed + "."; 
}

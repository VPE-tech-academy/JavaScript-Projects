window.alert("Welcome to Assignment XX")

function myFunction () {
    var Add = 2 + 2;
    document.getElementById("Math").innerHTML = " 2 + 2 = " + Add;
}